const express = require('express');
const Question = require('../models/Question');
const router = express.Router();

// public: list questions with simple filters
router.get('/', async (req,res) => {
  try{
    const { difficulty, tag, q } = req.query;
    const filter = {};
    if(difficulty) filter.difficulty = difficulty;
    if(tag) filter.tags = tag;
    if(q) filter.$text = { $search: q };
    const questions = await Question.find(filter).limit(100);
    res.json(questions);
  }catch(err){
    console.error(err); res.status(500).json({message:'server error'});
  }
});

router.get('/:id', async (req,res)=>{
  try{
    const q = await Question.findById(req.params.id);
    if(!q) return res.status(404).json({message:'Not found'});
    res.json(q);
  }catch(e){ console.error(e); res.status(500).json({message:'server error'}); }
});

module.exports = router;
