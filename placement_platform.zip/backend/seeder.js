require('dotenv').config();
const mongoose = require('mongoose');
const Question = require('./models/Question');

const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/placement_platform';

const sample = [
  { title: 'Two Sum', description: 'Given an array, find two numbers that add to target', difficulty:'easy', tags:['array','hashmap'], sampleInput:'[2,7,11,15], target=9', sampleOutput:'[0,1]' },
  { title: 'Reverse Linked List', description: 'Reverse a singly linked list', difficulty:'easy', tags:['linkedlist'], sampleInput:'1->2->3->4', sampleOutput:'4->3->2->1' },
  { title: 'LRU Cache', description: 'Design LRU Cache', difficulty:'hard', tags:['design','hashmap','linkedlist'], sampleInput:'', sampleOutput:'' }
];

mongoose.connect(MONGO).then(async ()=> {
  console.log('connected, seeding...');
  await Question.deleteMany({});
  await Question.insertMany(sample);
  console.log('seeded');
  process.exit();
}).catch(err => { console.error(err); process.exit(1); });
