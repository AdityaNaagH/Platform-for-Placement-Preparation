import React, {useEffect, useState} from 'react';
import api from '../api';

export default function Questions(){
  const [questions, setQuestions] = useState([]);
  useEffect(()=>{
    api.get('/questions').then(r=> setQuestions(r.data)).catch(e=> console.error(e));
  },[]);
  return (
    <div style={{padding:20}}>
      <h2>Questions</h2>
      {questions.length===0 && <p>No questions found (run backend seeder)</p>}
      <ul>
        {questions.map(q=> <li key={q._id}>
          <strong>{q.title}</strong> - {q.difficulty}
          <p>{q.description}</p>
        </li>)}
      </ul>
    </div>
  );
}
