import React from 'react';
export default function Home(){
  return (
    <div style={{padding:20}}>
      <h1>Placement Preparation Platform</h1>
      <p>Welcome! Use the Questions page to browse practice problems, or Login to save progress.</p>
    </div>
  );
}
