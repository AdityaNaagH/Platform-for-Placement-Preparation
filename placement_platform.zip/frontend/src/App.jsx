import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Questions from './pages/Questions';
import Login from './pages/Login';

export default function App(){
  return (
    <BrowserRouter>
      <div className="app">
        <nav className="nav">
          <Link to="/">Home</Link>
          <Link to="/questions">Questions</Link>
          <Link to="/login">Login</Link>
        </nav>
        <main>
          <Routes>
            <Route path="/" element={<Home/>} />
            <Route path="/questions" element={<Questions/>} />
            <Route path="/login" element={<Login/>} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}
